    const cartList = document.querySelector('.cart-list');
    const totalValue = document.querySelector('.total-value');
    const addToCartButtons = document.querySelectorAll('.buy-button');
    let cartItems = [];
  
      // Add event listener to each add-to-cart button
      addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
          const game = button.parentElement;
          const gameTitle = game-info.querySelector('h2').textContent;
          const gamePrice = parseInt(button.dataset.price);
          addItemToCart(gameTitle, gamePrice);
        });
      });
  
    
      // Add an item to the cart and update the cart UI
      function addItemToCart(title, price) {
      
      // Check if item is already in cart
      const existingItem = cartItems.find(item => item.title === title);
  
      if (existingItem) {
        existingItem.quantity++;
        updateCartUI();
      } else {
        const newItem = { title, price, quantity: 1 };
        cartItems.push(newItem);
        createCartItemUI(newItem);
      }
  
      updateTotalValue();
    }
  
    // Create a new cart item element and append to the cart list
    function createCartItemUI(item) {
      const cartItem = document.createElement('li');
      cartItem.innerHTML = `
        <span>${item.title} x ${item.quantity}</span>
        <span>$${item.price * item.quantity}</span>
      `;
      cartList.appendChild(cartItem);
    }
  
    // Update the cart UI with the current cart items
    function updateCartUI() {
      cartList.innerHTML = '';
      cartItems.forEach(item => {
        createCartItemUI(item);
      });
    }
  
    // Update the total value of the cart
    function updateTotalValue() {
      const total = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
      totalValue.textContent = total;
    }
